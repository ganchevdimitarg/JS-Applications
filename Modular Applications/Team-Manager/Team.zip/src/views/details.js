import {html} from "../../node_modules/lit-html/lit-html.js";
import {until} from "../../node_modules/lit-html/directives/until.js";
import {getTeamsById, reqToJoin, getReqsByTeamId, cancelMembership} from "../api/data.js";
import {loaderTemp} from "./common/loader.js";

const detailsTemp = (team, createControl) => html`
    <section id="team-home">
        <article class="layout">
            <img src=${team.logoUrl} class="team-logo left-col">
            <div class="tm-preview">
                <h2>${team.name}</h2>
                <p>${team.description}</p>
                <span class="details">3 Members</span>
                <div>
                    ${createControl()}
                </div>
            </div>
            <div class="pad-large">
                <h3>Members</h3>
                <ul class="tm-members">
                    <li>My Username</li>
                    <li>James<a href="#" class="tm-control action">Remove from team</a></li>
                    <li>Meowth<a href="#" class="tm-control action">Remove from team</a></li>
                </ul>
            </div>
            <div class="pad-large">
                <h3>Membership Requests</h3>
                <ul class="tm-members">
                    <li>John<a href="#" class="tm-control action">Approve</a><a href="#"
                                                                                class="tm-control action">Decline</a>
                    </li>
                    <li>Preya<a href="#" class="tm-control action">Approve</a><a href="#"
                                                                                 class="tm-control action">Decline</a>
                    </li>
                </ul>
            </div>
        </article>
    </section>

`;

export async function createDetailsPage(ctx) {
    const teamId = ctx.params.id;


    ctx.render(until(loadingTemp(teamId), loaderTemp()));


    async function loadingTemp(teamId) {
        const userId = sessionStorage.getItem('userId');
        const [team, requests] = await Promise.all([
            getTeamsById(teamId),
            getReqsByTeamId(teamId),
        ]);


        return detailsTemp(team, createControl);

        function createControl() {
            if (userId != null) {
                const request = requests.find(r => r._ownerId == userId);
                if (userId == team._ownerId) {
                    return html`<a href=${`/edit/${team._id}`} class="action">Edit team</a>`;
                } else if (request && request.status == 'member') {
                    return html`<a @click=${e => leave(e, request._id)} href="javascript:void(0)" class="action invert">Leave
                        team</a>`;
                } else if (request && request.status == 'pending') {
                    return html`Membership pending. <a @click=${e => leave(e, request._id)} href="javascript:void(0)">Cancel
                        request</a>`;
                } else {
                    return html`<a @click=${join} href="javascript:void(0)" class="action">Join team</a>`;
                }
            } else {
                return '';
            }
        }

        async function join() {
            await reqToJoin(teamId)
            ctx.render(await loadingTemp(teamId));
        }

        async function leave(event, requestId) {
            const confirmed = confirm('Do you want?');
            if (confirmed) {
                event.target.remove();
                await cancelMembership(requestId);
                ctx.render(await loadingTemp(teamId));
            }
        }
    }
}


