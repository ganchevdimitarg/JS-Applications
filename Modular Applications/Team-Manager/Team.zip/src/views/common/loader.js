import {html} from "../../../node_modules/lit-html/lit-html.js";

export const loaderTemp = () => html`<article class="pad-large"><h1><p>Loading&hellip;</p></h1></article>`;