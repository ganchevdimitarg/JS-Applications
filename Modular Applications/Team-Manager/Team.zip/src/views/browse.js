import {html} from "../../node_modules/lit-html/lit-html.js";
import {getTeams} from "../api/data.js";


const browseTemp = (teams) => html`
    <section id="browse">

        <article class="pad-med">
            <h1>Team Browser</h1>
        </article>
            <article class="layout narrow">
                <div class="pad-small"><a href="#" class="action cta">Create Team</a></div>
            </article>
        ${teams.map(createBrowseCard)}
    </section>
`;

const createBrowseCard = (teams) => html`
    <article class="layout">
        <img src=${teams.logoUrl} class="team-logo left-col">
        <div class="tm-preview">
            <h2>${teams.name}</h2>
            <p>${teams.description}</p>
            <span class="details">? Members</span>
            <div><a href="/details/${teams._id}" class="action">See details</a></div>
        </div>
    </article>
`;

export async function createBrowsePage(ctx) {
    const teams = await getTeams();
    ctx.render(browseTemp(teams));
}
